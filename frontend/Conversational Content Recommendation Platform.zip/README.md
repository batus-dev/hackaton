
  # Conversational Content Recommendation Platform

  This is a code bundle for Conversational Content Recommendation Platform. The original project is available at https://www.figma.com/design/K1UwzeRid8So6Zdzdo4ulw/Conversational-Content-Recommendation-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  